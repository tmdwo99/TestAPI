package org.dsu.dc.capston.controller;

public class AppController {

}
